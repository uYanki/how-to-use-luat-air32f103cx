#include "EPD_1in54.h"
#include "EPD_init.h"
#include "spi.h"
#include "delay.h"
#include "malloc.h" 

void EPD_1IN54_GPIO_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 //ʹ��A�˿�ʱ��
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_4;	 
 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//�ٶ�50MHz
 	GPIO_Init(GPIOA, &GPIO_InitStructure);	  //��ʼ��GPIOA
 	GPIO_SetBits(GPIOA,GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4);
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
}

void delay(int t)
{
	while(t--);
}

static const unsigned char EPD_1IN54_lut_full_update[] = {
    0x02, 0x02, 0x01, 0x11, 0x12, 0x12, 0x22, 0x22,
    0x66, 0x69, 0x69, 0x59, 0x58, 0x99, 0x99, 0x88,
    0x00, 0x00, 0x00, 0x00, 0xF8, 0xB4, 0x13, 0x51,
    0x35, 0x51, 0x51, 0x19, 0x01, 0x00
};

static const unsigned char EPD_1IN54_lut_partial_update[] = {
    0x10, 0x18, 0x18, 0x08, 0x18, 0x18, 0x08, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x13, 0x14, 0x44, 0x12,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

static const unsigned char EPD_1IN54_lut_update[] = {
    0x00, 0x01, 0x09, 0x08, 0x20, 0x00, 0x20, 0x00,
    0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x08, 0x00, 0x00, 0x01, 0x01, 0x05,
    0x01, 0x00, 0x01, 0x00, 0x01, 0x00
};

static const unsigned char EPD_1IN54_lut_test_update[] = {
    0x00, 0x01, 0x09, 0x08, 0x18, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x01,
    0x01, 0x00, 0x00, 0x00, 0x00, 0x00
};

static const unsigned char EPD_1IN54_lut_test2_update[] = {
	0x10, 0x18, 0x18, 0x28, 0x18, 0x18, 0x18, 0x18, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x13, 0x11, 0x22, 0x63, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00
};

//		0x10, 0x08, 0x18, 0x08, 0x00, 0x08, 0x00, 0x00,
//    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
//    0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x10,
//    0x00, 0x00, 0x00, 0x00, 0x01, 0x00

//		0x00, 0x01, 0x18, 0x08, 0x20, 0x00, 0x00, 0x00,
//    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
//    0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x03, 0x10,
//    0x01, 0x00, 0x00, 0x00, 0x00, 0x00

//		0x00, 0x01, 0x09, 0x08, 0x18, 0x00, 0x18, 0x00,
//    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
//    0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x01,
//    0x01, 0x00, 0x00, 0x00, 0x00, 0x00

uint8_t DEV_SPI_WriteByte(uint8_t TxData)
{
//	u8 retry = 0;				 	      
//	while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET) //0�����ͻ���ǿ�  �ȴ����ͻ��������
//	{
//		retry++;
//		if(retry>200){return 0;}
//	}			  
//	SPI_I2S_SendData(SPI1, TxData);
//	retry=0;
//	while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET)//���ָ����SPI��־λ�������:���ܻ���ǿձ�־λ
//		{
//		retry++;
//		if(retry>200)return 0;
//		}	  						    
//	return SPI_I2S_ReceiveData(SPI1); //����ͨ��SPIx������յ�����		
	while(SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);//�����ձ�־λ
	SPI_I2S_SendData(SPI1,TxData);
	delay(15);
	delay(1);
	delay(1);
	delay(1);
}

/******************************************************************************
function :	Software reset
parameter:
******************************************************************************/
static void EPD_1IN54_Reset(void)
{
    DEV_Digital_Write(EPD_RST_PIN, 1);
    DEV_Delay_ms(200);
    DEV_Digital_Write(EPD_RST_PIN, 0);
    DEV_Delay_ms(2);
    DEV_Digital_Write(EPD_RST_PIN, 1);
    DEV_Delay_ms(200);
}

/******************************************************************************
function :	send command
parameter:
     Reg : Command register
******************************************************************************/
void EPD_1IN54_SendCommand(uint8_t Reg)
{
    DEV_Digital_Write(EPD_DC_PIN, 0);
    DEV_Digital_Write(EPD_CS_PIN, 0);
    DEV_SPI_WriteByte(Reg);
    DEV_Digital_Write(EPD_CS_PIN, 1);
}

/******************************************************************************
function :	send data
parameter:
    Data : Write data
******************************************************************************/
void EPD_1IN54_SendData(uint8_t Data)
{
    DEV_Digital_Write(EPD_DC_PIN, 1);
    DEV_Digital_Write(EPD_CS_PIN, 0);
    DEV_SPI_WriteByte(Data);
    DEV_Digital_Write(EPD_CS_PIN, 1);
}

/******************************************************************************
function :	Wait until the busy_pin goes LOW
parameter:
******************************************************************************/
void EPD_1IN54_ReadBusy(void)
{
    while(DEV_Digital_Read(EPD_BUSY_PIN) == 1) {      //LOW: idle, HIGH: busy
        DEV_Delay_ms(100);
    }
}

/******************************************************************************
function :	Setting the display window
parameter:
******************************************************************************/
void EPD_1IN54_SetWindow(uint16_t Xstart, uint16_t Ystart, uint16_t Xend, uint16_t Yend)
{
    EPD_1IN54_SendCommand(0x44); // SET_RAM_X_ADDRESS_START_END_POSITION
    EPD_1IN54_SendData((Xstart >> 3) & 0xFF);
    EPD_1IN54_SendData((Xend >> 3) & 0xFF);

    EPD_1IN54_SendCommand(0x45); // SET_RAM_Y_ADDRESS_START_END_POSITION
    EPD_1IN54_SendData(Ystart & 0xFF);
    EPD_1IN54_SendData((Ystart >> 8) & 0xFF);
    EPD_1IN54_SendData(Yend & 0xFF);
    EPD_1IN54_SendData((Yend >> 8) & 0xFF);
}

/******************************************************************************
function :	Set Cursor
parameter:
******************************************************************************/
void EPD_1IN54_SetCursor(uint16_t Xstart, uint16_t Ystart)
{
    EPD_1IN54_SendCommand(0x4E); // SET_RAM_X_ADDRESS_COUNTER
    EPD_1IN54_SendData((Xstart >> 3) & 0xFF);

    EPD_1IN54_SendCommand(0x4F); // SET_RAM_Y_ADDRESS_COUNTER
    EPD_1IN54_SendData(Ystart & 0xFF);
    EPD_1IN54_SendData((Ystart >> 8) & 0xFF);
}

/******************************************************************************
function :	Turn On Display
parameter:
******************************************************************************/
void EPD_1IN54_TurnOnDisplay(void)
{
    EPD_1IN54_SendCommand(0x22); // DISPLAY_UPDATE_CONTROL_2
    EPD_1IN54_SendData(0xC4);
    EPD_1IN54_SendCommand(0x20); // MASTER_ACTIVATION
    EPD_1IN54_SendCommand(0xFF); // TERMINATE_FRAME_READ_WRITE

    EPD_1IN54_ReadBusy();
}

/******************************************************************************
function :	������ʾģʽ
parameter:
******************************************************************************/
void EPD_1IN54_Mode(uint8_t Mode)
{
	uint16_t i;
	
  //set the look-up table register
	EPD_1IN54_SendCommand(0x32);
	if(Mode == EPD_1IN54_FULL)
		{
     for (i = 0; i < 30; i++) 
			{
				EPD_1IN54_SendData(EPD_1IN54_lut_full_update[i]);
      }
    }
		else if(Mode == EPD_1IN54_PART)
			{
        for (i = 0; i < 30; i++) 
				{
          EPD_1IN54_SendData(EPD_1IN54_lut_partial_update[i]);
        }
			}
		else if(Mode == 2)
			{
				for (i = 0; i < 30; i++) 
				{
					EPD_1IN54_SendData(EPD_1IN54_lut_update[i]);
				}
			}
		else if(Mode == 3)
			{
				for (i = 0; i < 30; i++) 
				{
					EPD_1IN54_SendData(EPD_1IN54_lut_test_update[i]);
				}
			}
		else if(Mode == 4)
		{
			for (i = 0; i < 30; i++) 
			{
				EPD_1IN54_SendData(EPD_1IN54_lut_test2_update[i]);
			}
		}
}

void EPD_1IN54_Init()
{
		u16 Imagesize = ((EPD_1IN54_WIDTH % 8 == 0)? (EPD_1IN54_WIDTH / 8 ): (EPD_1IN54_WIDTH / 8 + 1)) * EPD_1IN54_HEIGHT;
		
		EPD_1IN54_GPIO_Init();
		SPI1_Init();
	
		DEV_Module_Init();
    EPD_1IN54_Reset();

    EPD_1IN54_SendCommand(0x01); // DRIVER_OUTPUT_CONTROL
    EPD_1IN54_SendData((EPD_1IN54_HEIGHT - 1) & 0xFF);
    EPD_1IN54_SendData(((EPD_1IN54_HEIGHT - 1) >> 8) & 0xFF);
    EPD_1IN54_SendData(0x00); // GD = 0; SM = 0; TB = 0;

    EPD_1IN54_SendCommand(0x0C); // BOOSTER_SOFT_START_CONTROL
    EPD_1IN54_SendData(0xD7);
    EPD_1IN54_SendData(0xD6);
    EPD_1IN54_SendData(0x9D);

    EPD_1IN54_SendCommand(0x2C); // WRITE_VCOM_REGISTER
    EPD_1IN54_SendData(0xAF); // VCOM 7C

    EPD_1IN54_SendCommand(0x3A); // SET_DUMMY_LINE_PERIOD
    EPD_1IN54_SendData(0x1A); // 4 dummy lines per gate

    EPD_1IN54_SendCommand(0x3B); // SET_GATE_TIME
    EPD_1IN54_SendData(0x08); // 2us per line

    EPD_1IN54_SendCommand(0x11);
    EPD_1IN54_SendData(0x03);
		
		EPD_1IN54_Mode(0);
    
    BlackImage = (u8 *)mymalloc(Imagesize);
		EPD_1IN54_Clear();
		Paint_NewImage(BlackImage, EPD_1IN54_WIDTH, EPD_1IN54_HEIGHT, 0, WHITE);
		
		Paint.Image=BlackImage;
		delay_ms(300);
		
}

/******************************************************************************
function :	����
parameter:
******************************************************************************/
void EPD_1IN54_Clear(void)
{
    uint16_t Width, Height;
		uint16_t i,j;
    Width = (EPD_1IN54_WIDTH % 8 == 0)? (EPD_1IN54_WIDTH / 8 ): (EPD_1IN54_WIDTH / 8 + 1);
    Height = EPD_1IN54_HEIGHT;
    EPD_1IN54_SetWindow(0, 0, EPD_1IN54_WIDTH, EPD_1IN54_HEIGHT);
    for (j = 0; j < Height; j++) {
        EPD_1IN54_SetCursor(0, j);
        EPD_1IN54_SendCommand(0x24);
        for (i = 0; i < Width; i++) {
            EPD_1IN54_SendData(0XFF);
        }
    }
    EPD_1IN54_TurnOnDisplay();
}

/******************************************************************************
function :	��RAM�е�ͼ�񻺳������͵�ˮī������ʾ
parameter:
******************************************************************************/
void EPD_1IN54_Display()
{
    u16 Width, Height;
		u16 i,j;
		u32 Addr = 0;
    Width = (EPD_1IN54_WIDTH % 8 == 0)? (EPD_1IN54_WIDTH / 8 ): (EPD_1IN54_WIDTH / 8 + 1);
    Height = EPD_1IN54_HEIGHT;
    
    // UDOUBLE Offset = ImageName;
    EPD_1IN54_SetWindow(0, 0, EPD_1IN54_WIDTH, EPD_1IN54_HEIGHT);
		EPD_1IN54_SetCursor(0, 0);
    EPD_1IN54_SendCommand(0x24);
    for (j = 0; j < Height; j++) {
        for (i = 0; i < Width; i++) {
            Addr = i + j * Width;
            EPD_1IN54_SendData(BlackImage[Addr]);
        }
    }
    EPD_1IN54_TurnOnDisplay();
}

int DEV_Module_Init(void)
{
    DEV_Digital_Write(EPD_DC_PIN, 0);
    DEV_Digital_Write(EPD_CS_PIN, 0);
    DEV_Digital_Write(EPD_RST_PIN, 1);
		return 0;
}

void DEV_Module_Exit(void)
{
    DEV_Digital_Write(EPD_DC_PIN, 0);
    DEV_Digital_Write(EPD_CS_PIN, 0);

    //close 5V
    DEV_Digital_Write(EPD_RST_PIN, 0);
}


