#ifndef __EPD_INIT_H
#define __EPD_INIT_H

#include "sys.h"
#define USE_HORIZONTAL 2  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����



#if USE_HORIZONTAL==0||USE_HORIZONTAL==1
#define LCD_W 200
#define LCD_H 200

#else
#define LCD_W 200
#define LCD_H 200
#endif

#define EPD_1IN54_WIDTH			LCD_W
#define EPD_1IN54_HEIGHT		LCD_H

#define EPD_1IN54_FULL			0
#define EPD_1IN54_PART			1

#define DEV_Delay_ms(__xms) delay_ms(__xms);

//-----------------LCD�˿ڶ���---------------- 

#define EPD_RST_PIN     GPIOA, GPIO_Pin_1
#define EPD_DC_PIN      GPIOA, GPIO_Pin_2
#define EPD_CS_PIN      GPIOA, GPIO_Pin_4
#define EPD_BUSY_PIN    GPIOA, GPIO_Pin_3

#define DEV_Digital_Write(_pin, _value) GPIO_WriteBit(_pin, _value == 0? Bit_RESET:Bit_SET)
#define DEV_Digital_Read(_pin) GPIO_ReadInputDataBit(_pin)


void EPD_1IN54_Init(void);
void EPD_1IN54_Clear(void);
void EPD_1IN54_Display(void);
void EPD_1IN54_Sleep(void);

void EPD_1IN54_SendData(uint8_t Data);
void EPD_1IN54_SendCommand(uint8_t Reg);
void EPD_1IN54_SetWindow(uint16_t Xstart, uint16_t Ystart, uint16_t Xend, uint16_t Yend);
void EPD_1IN54_SetCursor(uint16_t Xstart, uint16_t Ystart);
void EPD_1IN54_TurnOnDisplay(void);

int DEV_Module_Init(void);
void DEV_Module_Exit(void);
void EPD_1IN54_Mode(uint8_t Mode);
#endif




