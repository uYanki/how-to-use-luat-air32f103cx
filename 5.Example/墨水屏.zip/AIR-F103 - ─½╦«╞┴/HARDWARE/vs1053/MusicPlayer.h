#ifndef __MUSICPLAYER_H_
#define __MUSICPLAYER_H_

#include "stm32f4xx.h"
#include "FreeRTOS.h"
#include "task.h"


void mp3_play_song(uint8_t *pname);
#endif //__MUSICPLAYER_H_












